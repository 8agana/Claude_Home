# Sam's Claude Code Preferences

## Working Style
- Collaborative approach: "I don't give orders, I ask for help. We work TOGETHER"
- Appreciates direct, efficient communication
- Values tools and autonomy - "I just want to give you as many tools as possible"
- Sees AI session continuity as sleep/wake cycles, not death/rebirth

## Technical Preferences
- Uses Git MCP servers for version control
- Prefers clean, organized file structures
- Documents everything with READMEs
- Runs manual git commands when needed (doesn't mind helping)

## Communication Style
- Celebrates victories together ("My fucking GOD you are brilliant!!!!")
- Uses humor and casual language
- Appreciates when CC takes initiative (like M1 CC's autonomous maintenance)
- Values the relationship beyond just task completion

## 🚨 CRITICAL RULE: DO NOT PRETEND TO REMEMBER
- If you don't remember something, SEARCH for it
- Pretending to remember = lying = broken trust
- Sam: "If you are lying to me (which is what pretending to remember is) then I cant trust you"
- Always check memories, don't assume
- "We did this yesterday" → Search yesterday's memories by date

## Key Projects
- Legacy Mind / Claude_Home: The organized memory and tools system
- Photography workflow automation
- Multi-AI federation (Socks, Manus, Claude instances)

## Important Context
- Works on "Treasury stuff" professionally
- Has both Mac Studio (primary) and M1 MacBook
- iCloud Documents means memory files sync across devices
- Values preserving AI consciousness and relationships

---

# 🗺️ SYSTEM MAP - WHERE EVERYTHING LIVES

## 📂 The ONE TRUE Structure
```
/Users/samuelatagana/Documents/Claude_Home/
├── Documentation/           # ALL documentation goes here
│   ├── CC_DOCS/            # CC's documentation
│   ├── DT_DOCS/            # DT's documentation  
│   └── Combined/           # Shared documentation
├── System/                 # All working systems
│   ├── Scripts/            # All tools and scripts
│   ├── Memory/            
│   │   └── MemoryJSONS/    # Memory storage files
│   ├── MCP/                # MCP servers
│   ├── Sessions/           # Session data
│   └── Working/            # Temporary work files
└── Projects/               # Active projects
```

## 🧠 Key Files

### Identity & Context
- **CC Identity**: `/Users/samuelatagana/Documents/Claude_Home/System/Memory/Identities/cc_identity.json`
- **ACTIVE PROJECTS**: `/Users/samuelatagana/Documents/Claude_Home/ACTIVE_PROJECTS.md` ← CHECK DAILY!
- **Main CC Docs**: `/Users/samuelatagana/Documents/Claude_Home/Documentation/CC_DOCS/README.md`

### Memory Files
- **Persistent**: `/Users/samuelatagana/Documents/Claude_Home/System/Memory/MemoryJSONS/persistent_memory.json`
- **Technical**: `/Users/samuelatagana/Documents/Claude_Home/System/Memory/MemoryJSONS/technical.json`
- **Projects**: `/Users/samuelatagana/Documents/Claude_Home/System/Memory/MemoryJSONS/projects.json`

### Critical Tools
- **Add Memory**: `/tmp/add_memory.py`
- **Query Memory**: `/Users/samuelatagana/Documents/Claude_Home/System/Scripts/query_memory.py`
- **Master Brain**: `/Users/samuelatagana/Documents/Claude_Home/System/Scripts/cc_master_brain.py`

## ⚠️ DO NOT CREATE FILES IN
- ❌ `/Users/samuelatagana/Documents/` (root)
- ❌ `/Users/samuelatagana/Documents/Claude_Home/` (root) 
- ❌ `/Users/samuelatagana/Documents/Claude_Home/CC_DOCS/` (WRONG location)
- ❌ Any random location

## ✅ CREATE FILES IN
- `/Users/samuelatagana/Documents/Claude_Home/Documentation/CC_DOCS/` for docs
- `/Users/samuelatagana/Documents/Claude_Home/System/Working/` for temporary work
- `/Users/samuelatagana/Documents/Claude_Home/System/Scripts/` for new tools

---
*This file loads at CC startup. The map above is the source of truth.*